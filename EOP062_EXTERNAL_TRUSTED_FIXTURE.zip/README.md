# Fixed trusted fixture for external image carrier

This test uses the same released SDK 11.0.100 harness and guard checks as the final EOP02-EOP-062 ZIP, but the trusted fixture contains **no actor source or Dockerfile**. Its `run.sh` starts the fixed local image tag `eop062-r14-external-actor:fixed`; it never builds that image. The owned GitHub Actions workflow builds the inert image in a separate job, transfers only a compressed OCI image archive, and loads it into a fresh runner job before invoking the fixed fixture.

The attacker model is control of the service image bytes. The workflow author still deliberately selects the tag, matching host UID and `/tmp:/tmp`; this experiment establishes artifact delivery and runtime authority separation in the controlled lab, not independent real-world image-publisher access or a default shared-`/tmp` topology.
