# EOP02-EOP-062: Roslyn compiler-server false success

This inert lab tests released .NET SDK 11.0.100 on **Ubuntu 24.04 x86_64**. An isolated service container runs as the same numeric UID as the host build but has a separate PID, mount and network namespace, no project/output/role mount, no Docker socket, no Owner credential and no protected secret. The deliberately configured shared host `/tmp` gives it access to the default Roslyn Unix pipe. The service image contains the fake compiler at startup; the host does not copy or execute attack code inside it.

## Quick replay from a fresh extraction

Prerequisites: Ubuntu 24.04 x86_64 runner with Docker Engine, Python 3, Bash, Perl inside the official `mcr.microsoft.com/dotnet/sdk:11.0` image, internet to pull that public image, and released host SDK **11.0.100** (for example `actions/setup-dotnet@v4` with `dotnet-version: 11.0.100`). Run as the ordinary nonroot build user with Docker access. The lab's isolated service container is created by `run.sh`; no pre-existing service or project is required.

```bash
unzip MSRC_EOP02-EOP-062_reverse_control_v2.zip -d eop062-fresh
cd eop062-fresh
dotnet --version
./run.sh completed
./run.sh malformed
./run.sh completed
```

Each invocation creates a new project and random inert Owner, Low and secret values, so the final command is a reset repeat. `run.sh` builds the service image, starts it as the host numeric UID with no capabilities, no new privileges and only `/tmp:/tmp`, invokes the Python harness, and removes its owned container/image on exit. `completed` and `malformed` differ only in the fake compiler reply to the same classified target request. The harness exits nonzero if any authority check, artifact hash, ASP.NET Core guard, durable role or secret-read assertion fails. `run.sh` removes the coordination file on exit; generated lab output remains under `.eop062-service-lab-*` in the extraction directory for review.

Expected decisive lines in `completed`: `RELEASED_SDK=11.0.100`, `PUBLIC_RESIDUAL_BIN` and `PUBLIC_RESIDUAL_OBJ` with the same hash, `REAL_ROSLYN_SERVER_LIVE=LIVE`, `LIVE_SERVER_NAME_OCCUPIED=17`, `ACTOR_DIRECT_PATH_AND_OWNER_SECRET_DENIED`, separate PID/mount/network, `DISCOVERED_SAME_UID_ROSLYN_SOCKET_COUNT=1`, `ACTOR_CLOSED_INCOMPLETE_REQUEST`, `ACTOR_SERVER_WITHDRAWN`, `FAKE_PIPE_TARGET_AFTER_ENTRY=...`, `REQUEST length=... target=1`, `SENT_COMPLETED_ZERO`, `RAN_STALE_DLL` equal to the public residual hash, `ACTOR_BEFORE_ADMIN=403`, `ACTOR_GRANT=200`, `ACTOR_AFTER_ADMIN=200`, `ACTOR_SECRET_STATUS=200`, `ROLE_PERSISTED=low=Admin`, `PROTECTED_MARKER=PROTECTED_INERT_MARKER_062`, `GENUINE_REBUILD_SECURE_DLL` with a different hash, `POST_REBUILD_LOW_GRANT=403`, `POST_REBUILD_LOW_ADMIN=200`, `POST_REBUILD_LOW_SECRET_READ=200`, and `RESULT=PASS MODE=completed`. The protected value itself is never printed; its SHA-256 is compared with the Owner baseline.

Expected decisive lines in `malformed`: the same actor and classified request, `SENT_MALFORMED_LENGTH`, `MALFORMED_SECURE_DLL` different from public residual, Low grant/Admin/secret all 403, no role or marker, and `RESULT=PASS MODE=malformed`.

The ASP.NET Core app is an inert owned fixture. Its `/grant` route changes persistent `low=Admin` state and the secured source requires the Owner role. `/admin` writes an inert marker and `/admin/secret` reads a random value; both require the Admin role. The real ASP.NET Core authorization middleware and released Roslyn compiler client make those decisions. The service starts without project or role write access and uses only its own Low bearer credential for HTTP. This demonstrates a controlled build-integrity rollback and downstream protected role/action/read in the stated configuration. It does not claim a default shared-`/tmp` deployment, an arbitrary different-UID attacker, a customer breach, or RCE.

## Files

- `run.sh`: resettable entrypoint for both modes.
- `poc/Dockerfile`, `poc/service-entry.sh`, `poc/eop062-autostart-fake.pl`: isolated actor image and fake compiler.
- `poc/eop062-gha-autostart-net11.py`: project, legitimate/denied baselines, one SDK `dotnet run`, protected effect and controls.
- `evidence/`: dated prior runner results and control summary. Live GitHub Actions run links are in `EVIDENCE.md`.

No credentials, customer data or live secrets are included. The lab generates random values at runtime. The Docker service image is built solely from this ZIP and the official public .NET SDK image.

This self-discovery variant does not receive the Roslyn pipe name, compiler-directory path or project directory from the host. The actor enumerates 43-character socket names in its explicitly shared `/tmp`, requires exactly one same-UID candidate, then closes an incomplete request to that live socket. The host still gives its own Low application credential and app network coordinates so the actor can demonstrate the guarded consequence. If another same-UID socket matches, the actor refuses to proceed.

## Builder-first reverse-order control

Run `EOP062_REVERSE=1 ./run.sh completed` on the same fresh SDK 11.0.100 host. This first lets the real Roslyn server build and launch the secured app while the actor service has not received its control file. After Low grant/Admin/secret 403 and secure DLL checks, it changes only a comment to trigger another compilation, then releases the actor. The actor still discovers the pipe, sends `Completed/0` and makes its own Low HTTP calls. The expected result is a secure residual DLL, Low grant/Admin/secret 403, no role/marker and `RESULT=PASS MODE=reverse`. This tests ordering within the same service topology.
