# EOP02-EOP-062 supplementary Landlock PoC

Archive: `MSRC_EOP02-EOP-062_Landlock_v1.zip`. This is the same Roslyn compiler-server false-success root as the primary v3 PoC, with a different same-UID actor confinement configuration.

## Run

On a clean Ubuntu 24.04 x86_64 runner with released .NET SDK 11.0.100, Perl, Python 3, a C compiler, Linux Landlock ABI >= 3 and Yama `ptrace_scope >= 1`:

```sh
unzip -q MSRC_EOP02-EOP-062_Landlock_v1.zip -d eop062-landlock-replay
cd eop062-landlock-replay
./run.sh
```

Expected final line: `LANDLOCK_ZIP_REPLAY=PASS`. The script performs fresh valid → malformed → valid cases. Each creates a real ASP.NET Core 11.0 app, confirms Low denied and Owner allowed on a secure build, leaves normal public `bin`/`obj` output, edits source secure, then makes one SDK `dotnet run` while a confined attacker process handles the actual compiler request. Valid `Completed/0` leaves stale public output and lets the actor's own Low app credential persist Admin, write the Admin marker and read a protected value; a genuine secure rebuild restores the grant denial but not the persisted role. Malformed wire builds secure output and denies the Low effects. The actor independently discovers the same-UID `/tmp` socket; no pipe name is supplied.

The attacker code runs under the same OS UID but only after a Landlock ruleset restricts source/output/role and parent `/proc` file access. It gets its own Low application credential and app port. A separate harmless signal probe confirms its parent is live, and a `PTRACE_ATTACH` attempt must be denied. The host harness authors and launches the actor; this archive proves the controlled file/process authority split and released product behavior, not an ordinary independent malware-delivery path. Same UID is a material MSRC boundary objection. This does not prove arbitrary compilation, RCE, customer compromise or a cross-user exploit.

No owner token, protected secret value or external service is required. The test creates random local credentials and logs only hashes/statuses. It requires no Docker, VM, privileged account or local source build of .NET. Use the separate primary v3/reverse-v2 ZIPs for the container and builder-first controls.
