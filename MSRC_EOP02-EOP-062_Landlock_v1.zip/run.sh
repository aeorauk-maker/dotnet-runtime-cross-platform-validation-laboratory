#!/usr/bin/env bash
set -euo pipefail
here=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
cd "$here"
test "$(uname -m)" = x86_64
test "$(dotnet --version)" = 11.0.100
test -r /proc/sys/kernel/yama/ptrace_scope
ptrace_scope=$(cat /proc/sys/kernel/yama/ptrace_scope)
test "$ptrace_scope" -ge 1
echo "PTRACE_SCOPE=$ptrace_scope"
python3 -m py_compile poc/eop062-landlock-net11.py
perl -c poc/eop062-landlock-fake.pl
cc -O2 -Wall -Wextra -o poc/landlock-launch poc/landlock-launch.c
poc/landlock-launch /usr/bin/id -u
export GITHUB_WORKSPACE="$here"
EOP062_MODE=completed python3 poc/eop062-landlock-net11.py
EOP062_MODE=malformed python3 poc/eop062-landlock-net11.py
EOP062_MODE=completed python3 poc/eop062-landlock-net11.py
echo LANDLOCK_ZIP_REPLAY=PASS
