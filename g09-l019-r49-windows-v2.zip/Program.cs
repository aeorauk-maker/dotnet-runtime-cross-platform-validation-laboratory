using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text.Json;

var cases = new (string Group, string Eku, string[] Files)[] {
    ("inherited-exact", "1.3.6.1.5.5.7.3.2", new[] {
        "root-forbidden.der", "allowed.der", "forbidden.der",
        "cn-forbidden-san-allowed.der", "trailing-zero.der", "trailing-null.der" }),
    ("same-serial-nosan", "1.3.6.1.5.5.7.3.1", new[] {
        "root-forbidden.der", "allowed.der", "forbidden.der",
        "cn-forbidden-san-allowed.der", "trailing-zero-same-serial.der", "no-san.der" }),
};
var results = new List<object>();
foreach (var group in cases) {
    using var root = X509CertificateLoader.LoadCertificateFromFile(Path.Combine(group.Group, "root.der"));
    using var intermediate = X509CertificateLoader.LoadCertificateFromFile(Path.Combine(group.Group, "intermediate.der"));
    foreach (var file in group.Files) {
        try {
            using var leaf = X509CertificateLoader.LoadCertificateFromFile(Path.Combine(group.Group, file));
            using var chain = new X509Chain();
            chain.ChainPolicy.TrustMode = X509ChainTrustMode.CustomRootTrust;
            chain.ChainPolicy.CustomTrustStore.Add(root);
            chain.ChainPolicy.ExtraStore.Add(intermediate);
            chain.ChainPolicy.RevocationMode = X509RevocationMode.NoCheck;
            chain.ChainPolicy.VerificationFlags = X509VerificationFlags.NoFlag;
            chain.ChainPolicy.ApplicationPolicy.Add(new Oid(group.Eku));
            bool built = chain.Build(leaf);
            var san = leaf.Extensions.Cast<X509Extension>().Where(x => x.Oid?.Value == "2.5.29.17").ToArray();
            string? sanFormat = null, sanFormatError = null;
            if (san.Length == 1) {
                try { sanFormat = san[0].Format(false); }
                catch (Exception e) { sanFormatError = e.GetType().Name + ":" + e.HResult; }
            }
            string? dnsName = null, dnsNameError = null, sanOnlyName = null, sanOnlyError = null;
            try { dnsName = leaf.GetNameInfo(X509NameType.DnsName, false); }
            catch (Exception e) { dnsNameError = e.GetType().Name + ":" + e.HResult; }
            try { sanOnlyName = leaf.GetNameInfo(X509NameType.DnsFromAlternativeName, false); }
            catch (Exception e) { sanOnlyError = e.GetType().Name + ":" + e.HResult; }
            bool? matchesAllowed = null, matchesForbidden = null;
            string? matchError = null;
            try {
                matchesAllowed = leaf.MatchesHostname("allowed.test");
                matchesForbidden = leaf.MatchesHostname("forbidden.test");
            }
            catch (Exception e) { matchError = e.GetType().Name + ":" + e.HResult; }
            results.Add(new {
                group = group.Group, file,
                sha256 = Convert.ToHexString(SHA256.HashData(leaf.RawData)),
                serial = leaf.SerialNumber, subject = leaf.Subject,
                built, statuses = chain.ChainStatus.Select(x => x.Status.ToString()).ToArray(),
                elements = chain.ChainElements.Cast<X509ChainElement>().Select(x => new {
                    subject = x.Certificate.Subject,
                    statuses = x.ChainElementStatus.Select(s => s.Status.ToString()).ToArray() }).ToArray(),
                sanCount = san.Length, sanRawHex = san.Length == 1 ? Convert.ToHexString(san[0].RawData) : null,
                sanFormat, sanFormatError, dnsName, dnsNameError, sanOnlyName, sanOnlyError,
                matchesAllowed, matchesForbidden, matchError
            });
        }
        catch (Exception e) { results.Add(new { group = group.Group, file, loadError = e.ToString() }); }
    }
}
Console.WriteLine(JsonSerializer.Serialize(new {
    runtime = RuntimeInformation.FrameworkDescription,
    os = RuntimeInformation.OSDescription,
    cryptoAssembly = typeof(X509Certificate2).Assembly.Location,
    cryptoSha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(typeof(X509Certificate2).Assembly.Location))),
    results
}, new JsonSerializerOptions { WriteIndented = true }));
