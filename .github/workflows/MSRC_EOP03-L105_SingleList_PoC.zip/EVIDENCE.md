# EOP03-L105 single-list claim and evidence

## Exact released decision

The tested worker is IIS in-process .NET runtime 11.0.0 on Windows Server 2025 x64, SDK 11.0.100. Released dotnet-trace 10.0.750501 attaches to the real diagnostic endpoint before the attack. The privileged consumer is separately installed released dotnet-monitor 10.0.5, which bundles Microsoft.Diagnostics.NETCore.Client/0.2.746706. The bundled DLL SHA-256 is a0f14b6701b8579e9d41dc4d9229b8ae09565b720f66f892430591f3d4785db1. The monitor's Version.Details.xml pins diagnostics source commit a8e8b10f5f05acc3acad76a4fa5db0e1ebbb341c; its Windows IpcTransport.cs connects to the PID pipe with TokenImpersonationLevel.Impersonation and does not verify the selected server instance. See RELEASE-CORRESPONDENCE.md and the original release files under release/.

The lower IIS worker binds another server instance named dotnet-diagnostic-{its own PID} after the genuine runtime endpoint exists. This is not first-instance squatting. The lower code also holds two client connections to the genuine instance before binding its own; pinned runtime source shows a new listener is opened after accept, then the diagnostic server waits indefinitely for a message header. This source reasoning is corroborated by a matched one-factor Windows outcome, not a universal instance-selection guarantee.

## Causal matrix

| Question | Positive | Control or limitation |
| --- | --- | --- |
| Authentic target and lower actor | Genuine released trace succeeds; lower IIS APPPOOL SID, two held genuine connections, and later same-PID server bind are logged in both successful jobs. | Direct lower Admin/SYSTEM file read/write and SCM create return access denied/ERROR=5. |
| Ordinary monitor request | Elevated Administrator monitor stays alive without ProcessName filter; one authenticated no-PID GET /processes by a separate ADMIN=False caller returns HTTP 200 and contacts fake after the holds. | No-request gives no contact. Unauthenticated GET /processes returns 401/no contact. Two matched one-request jobs without holds return 200 but miss the fake. The API key belongs to the deliberately authorized caller, not the IIS attacker. |
| Released grant and protected effect | First IPC byte 68, exact monitor Administrator RID500 SID at Impersonation, Admin-only read/write and SCM create/start succeed. | One-right SeImpersonate-disable run reaches fake but gets Identification; protected operations fail. Direct SYSTEM-only write under impersonated Administrator is denied. |
| Downstream consequence | App-pool-placed Auto/LocalSystem service remains Running after monitor and worker stop, then service SID S-1-5-18 makes delayed SYSTEM-only write; cleanup passes. | No OS reboot, remote-only starting actor, default elevated monitor deployment, customer prevalence or guaranteed .NET bounty inclusion is proved. |

## Full job logs

All listed normalized logs are included under evidence/ and should be read at the runtime result section, after the printed source and setup output:

| File | Windows job | SHA-256 | Meaning |
| --- | --- | --- | --- |
| pa30-68-held-genuine-one-list-run1-job.log | https://github.com/aeorauk-maker/dotnet-runtime-cross-platform-validation-laboratory/actions/runs/46169182131/job/141053452411 | 001f976129119a60f7349b90013a9951179ab66f780a280b075c6e60e54fb410 | One authorized list, both genuine holds, full protected terminal and cleanup. |
| pa30-70-held-genuine-one-list-run2-job.log | https://github.com/aeorauk-maker/dotnet-runtime-cross-platform-validation-laboratory/actions/runs/46169182131/job/141054938076 | eed86845e576f7acf2b5bb7ca69ab9be5dba6d1e43514d373e3418d7335337b0 | Exact unchanged fresh repeat, different worker and service PIDs, full terminal. |
| pa30-66-one-list-run1-job.log | https://github.com/aeorauk-maker/dotnet-runtime-cross-platform-validation-laboratory/actions/runs/46167919798/job/141049508485 | 2e506cb8bdd7966e436b016cc93ca5a6f1af99f865dabe2ddb587909fef17853 | No-hold one-list selector miss after valid controls and HTTP 200. |
| pa30-66-one-list-run2-job.log | https://github.com/aeorauk-maker/dotnet-runtime-cross-platform-validation-laboratory/actions/runs/46167919798/job/141051104962 | b7e541595e4b1b055e19ce1a07c37e365b5dfb60babb8c970bd6ab42457054cb | Exact no-hold repeat, same selector miss. |
| pa30-51-no-seimp-v2-run1-job.log | https://github.com/aeorauk-maker/dotnet-runtime-cross-platform-validation-laboratory/actions/runs/46159614609/job/141023764798 | 86dee886fe5cf5e5ca5f1e97edd8278540e6257ac8b3ce1c9c926ea70a56a72f | One-right negative: same pipe contact, Identification only, protected effect denied. |

The two held-genuine jobs differ only in fresh-run machine state and PIDs, not workflow source. The two no-hold jobs differ by the deliberate absence of the two held connections. The exact held-genuine archive has to pass fresh clean extraction before it can be called report-ready.

## Boundary, severity and novelty limits

The Microsoft-owned failing decision is the released Windows diagnostics client's grant of Impersonation-level access to a potentially hostile same-PID server instance. Windows named-pipe instance selection and the lower actor's enabled SeImpersonatePrivilege are necessary conditions. A mere server-PID comparison would not distinguish this same-process later instance from the genuine runtime; the stronger guard is avoiding an exploitable token grant to an untrusted process or authenticating the actual channel.

This is local processing-resource integrity and LocalSystem execution in the owned lab, supporting an Important EoP technical opinion. A valid general monitor API key and elevated monitor deployment remain required. The default monitor HTTP binding is localhost and authentication is enabled. No unauthenticated remote-to-SYSTEM or Critical chain is joined.

The .NET bounty publicly lists supported .NET and ASP.NET Core but does not expressly list separately installed dotnet-trace/dotnet-monitor; both released tools' security guidance says MSRC reports may qualify. Eligibility remains Review. CVE-2023-33127 repaired an older runtime diagnostic-server ownership guard, while the tested attack abuses a later elevated-client impersonation decision. Public dotnet/diagnostics PR 6133 discusses Unix peer validation and spoofed candidates; it does not establish private novelty or fix the examined Windows branch. Do not label this root wholly novel or submit a second report for the held-connection schedule.
