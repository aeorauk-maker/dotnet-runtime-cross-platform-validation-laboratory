# EOP03-L105 single-list Windows PoC

This controlled PoC tests a lower IIS app-pool worker taking an elevated released dotnet-monitor named-pipe client token, then creating an app-pool-placed LocalSystem service. The service stays Running after the monitor and worker stop and later writes a SYSTEM-only file. The starting actor already has code execution in a lower IIS worker with enabled SeImpersonatePrivilege. The monitor is separately installed and deliberately elevated. A different, non-Administrator OS caller is deliberately given a temporary general monitor API key and makes one authorized process-list request. This is a local EoP proof, not an anonymous remote trigger.

## Clean reproduction

Use a fresh disposable Windows Server 2025 x64 host with elevated PowerShell 7, internet access to official Microsoft .NET/NuGet downloads, and .NET SDK 11.0.100. From a fresh directory containing this archive:

    Expand-Archive -LiteralPath .\MSRC_EOP03-L105_SingleList_PoC.zip -DestinationPath .\EOP03-L105-single-list
    Set-Location .\EOP03-L105-single-list
    pwsh -NoProfile -ExecutionPolicy Bypass -File .\run.ps1

The script prints BuildLabEx and versions; installs the signed .NET 11.0.0 Hosting Bundle and released dotnet-trace 10.0.750501/dotnet-monitor 10.0.5; configures disposable IIS, local ACLs, the temporary monitor API key and an inert service fixture. It only uses localhost HTTP ports 8911, 52401 and 52402. It refuses an existing scratch directory or proof service. Run only on an owned disposable host.

The run is successful only if the complete matrix appears:

1. Released dotnet-trace first attaches to the genuine .NET 11 IIS worker and writes nonempty trace data. The lower app-pool SID directly fails Admin/SYSTEM ACL read/write and SCM create.
2. Under that exact lower SID, the worker opens and holds two connections to its genuine diagnostic pipe before it binds the later same-PID server instance. Both GENUINE_HOLD*_CONNECTED lines and PIPE_BOUND=True must be present. This temporarily stalls the worker's genuine diagnostic handling; it is an explicit attacker action that improves instance selection.
3. The unfiltered elevated monitor has no fake-pipe contact while idle. An unauthenticated GET /processes returns HTTP 401 and still has no contact.
4. A distinct non-Administrator OS user with a deliberately delegated one-run general API key sends exactly one no-PID authenticated GET /processes. It receives HTTP 200. The substitute pipe receives first IPC byte 68 and the exact monitor Administrator SID at Impersonation level. The lower callback performs Admin-only read/write and SCM open/create/start. A direct SYSTEM-only write under the Administrator token remains denied.
5. After the monitor and IIS worker stop, the same Auto/LocalSystem service PID stays Running. It records STARTED_SID=S-1-5-18 and makes the delayed SYSTEM-only write. The service and temporary account are then removed. The final PASS line alone is insufficient; inspect the preceding identity, denial and service-state lines.

The included runner/github-workflow.yml checks out the exact ZIP, prints its SHA-256 and the extracted run.ps1 SHA-256, extracts to a fresh directory and runs that script on an owned Windows runner. For a repeat, use the same archive SHA-256 on a second fresh host. If an experiment fails before cleanup, discard the disposable runner.

## What this proves and does not prove

Two fresh inline workflow jobs at the exact same source commit completed the full chain, while two matched one-request jobs without the genuine-connection holds got HTTP 200 but missed the substitute instance. The attached evidence logs include those outcomes and a one-right negative: disabling only SeImpersonatePrivilege retains pipe contact but yields Identification and denied protected action. This ZIP itself must still be verified by clean extraction; successful inline jobs do not substitute for that gate.

The lower actor never receives the monitor API key in this PoC and does not force the authorized caller to make the request. The monitor's elevated deployment, the app-pool code foothold, enabled SeImpersonatePrivilege and held-connection timing are real prerequisites. No reboot or customer host was tested. Auto is an observed SCM setting, not reboot-survival proof. Technical impact is local EoP to a LocalSystem service in the controlled lab. The exact .NET bounty inclusion of separately installed diagnostics tools and private duplicate status remain unresolved. The same-root public Unix peer-PID work in dotnet/diagnostics PR 6133 is separately discussed in the evidence map. This archive is not an MSRC submission and contains no customer data or live credentials.
