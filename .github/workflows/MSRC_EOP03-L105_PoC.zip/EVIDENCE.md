# EOP03-L105 claim-to-evidence map

## Product and environment

- Tested on fresh GitHub-hosted Windows Server 2025 x64 runners, with .NET SDK `11.0.100`, signed .NET Hosting Bundle/runtime `11.0.0`, released `dotnet-trace 10.0.750501` and released `dotnet-monitor 10.0.5` installed by the PoC. The clean-archive replay prints `BUILDLABEX`; earlier inline workflow runs did not log that registry field, so do not invent its value for them.
- The failing Windows client decision is in [`Microsoft.Diagnostics.NETCore.Client/DiagnosticsIpc/IpcTransport.cs`](https://github.com/dotnet/dotnet/blob/v11.0.100/src/diagnostics/src/Microsoft.Diagnostics.NETCore.Client/DiagnosticsIpc/IpcTransport.cs), .NET unified source tag `v11.0.100`, Git blob `a8b287f0041b3922601d5ef009151b663704a77b`. The same blob appears in the released `dotnet/diagnostics` commit `ad724c4b85e7ae775e42f393c6e95a7557a57954` for `dotnet-trace 10.0.750501`. Its Windows named-pipe connects pass `TokenImpersonationLevel.Impersonation` (source lines 69 and 111). The released monitor's `/processes` implementation enumerates discovered PIDs and sends process-info requests; its bearer auth gate is genuine and the 401 control is observed.
- The official [.NET diagnostic-port description](https://learn.microsoft.com/en-us/dotnet/core/diagnostics/diagnostic-port) says the default Windows address is `dotnet-diagnostic-{PID}` and its security boundary is same-user/super-user access. The attack occurs **after the genuine endpoint exists** and uses a second instance under the same app-pool identity. The relevant elevated-client trust decision is independent of the prior CVE-2023-33127 runtime first-instance ownership repair.

## Claim matrix

| Causal question | Positive evidence | Adverse control / limit |
| --- | --- | --- |
| Lower actor and pipe | Two exact clean-run inline workflow logs `pa30-55`/`pa30-56`: `APPPOOL_SID=S-1-5-82-...`, `DIRECT_DENIED=True`, `PIPE_BOUND=True`, distinct worker PIDs 4392/7600 | Direct protected read/write, SYSTEM-only write and SCM create fail before client contact. The app-pool token does have enabled `SeImpersonatePrivilege`; this is a measured prerequisite, not direct Admin/SYSTEM access. |
| Real product baseline and request selector | `VALID_TRACE_EXIT=0` with >1.7 MB; elevated monitor alive unfiltered; separate low OS caller SID `S-1-5-21-...-1003`, `ADMIN=False`, six authenticated no-PID `/processes` 200 responses per run | Idle/no-request: `NO_FILTER_PRE_API_FAKE_CONTACT=False`; unauthenticated request: HTTP 401 and no contact. The key was deliberately delegated to the authorized caller; attacker-held key is unproved. |
| Product grant and protected action | `FIRST_BYTE=68`, monitor Admin SID `...-500` at `IMPERSONATION_LEVEL=Impersonation`, Admin-only protected read/write, `IMPERSONATED_SCM_OPEN/CREATED/START=True` | Direct SYSTEM-only write under the Admin token fails and original content remains. Single-right `SeImpersonatePrivilege` disable leaves pipe contact but gives Identification and denied protected read. |
| Downstream consequence | `SERVICE_START_MODE=Auto`, `SERVICE_ACCOUNT=LocalSystem`, `SERVICE_RUNNING_AFTER_WORKER_STOP=True`, service PID 5588/2404 unchanged across delay, `STARTED_SID=S-1-5-18`, `SYSTEM_MARKER_WRITTEN_AFTER_DELAY=True`, cleanup pass | No OS reboot, customer host, anonymous trigger, default elevated monitor deployment or Critical-prevalence claim. The service fixture is inert and owned by the lab; its purpose is to prove the SCM guard and SYSTEM execution. |

Full normalized logs in `evidence/`:

| File | GitHub Actions job | SHA-256 |
| --- | --- | --- |
| `pa30-55-nonadmin-v3-run1-job.log` | [141028792409](https://github.com/aeorauk-maker/dotnet-runtime-cross-platform-validation-laboratory/actions/runs/46161235638/job/141028792409) | `aa71da1f24eb4f6b4c6d9b9f384af04f3f823f8da1e1da44f0e1504caddd713b` |
| `pa30-56-nonadmin-v3-run2-job.log` | [141030321760](https://github.com/aeorauk-maker/dotnet-runtime-cross-platform-validation-laboratory/actions/runs/46161235638/job/141030321760) | `da08e5df155ff60ea72abe0be02ad8cc848832bb060790c78afc275683bdf373` |
| `pa30-51-no-seimp-v2-run1-job.log` | [141023764798](https://github.com/aeorauk-maker/dotnet-runtime-cross-platform-validation-laboratory/actions/runs/46159614609/job/141023764798) | `86dee886fe5cf5e5ca5f1e97edd8278540e6257ac8b3ce1c9c926ea70a56a72f` |
| `pa30-48-admin-run1-job.log` | [141019215741](https://github.com/aeorauk-maker/dotnet-runtime-cross-platform-validation-laboratory/actions/runs/46158138697/job/141019215741) | `9f7ddb90ae680d91f26859d29b2c6c77ab42d4d1bdc508356e3657ff7b8c5745` |
| `pa30-49-admin-run2-job.log` | [141020345952](https://github.com/aeorauk-maker/dotnet-runtime-cross-platform-validation-laboratory/actions/runs/46158138697/job/141020345952) | `d39682c4351a36cad53155eff9cc5ab0704fc627fd17c2ec1b378bc8bbbce33e` |

## Scope and distinctness limits

The [current .NET bounty list](https://www.microsoft.com/en-us/msrc/bounty-dot-net-core) names supported .NET/ASP.NET Core but does not expressly list separately installed diagnostic tools. The released tools' `SECURITY.md` files direct reports to MSRC and say they *may* qualify. The byte-identical transport appears in the supported .NET 11 unified source, yet bounded searches of ordinary SDK/runtime/ASP.NET Core callers did not find a release-shipped privileged consumer that normally selects an unrelated IIS worker. This is **program inclusion Review**, not a technical refutation or a confirmed bounty ruling.

The closest public prior, [CVE-2023-33127](https://github.com/dotnet/runtime/security/advisories/GHSA-485r-rp8v-998v), describes a runtime diagnostic-server cross-user EoP in earlier .NET 6/7 versions. This PoC targets a released elevated **client** that grants impersonation after a genuine runtime endpoint is already live; the 2023 first-instance runtime guard does not stop the observed second-instance client connection. This is a causal distinction, not proof of private novelty. No MSRC case submission/contact or third-party exploitation evidence is claimed.
