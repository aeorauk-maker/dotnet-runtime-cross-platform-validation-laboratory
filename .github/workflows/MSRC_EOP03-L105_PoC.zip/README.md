# EOP03-L105 Windows diagnostic-pipe second-instance PoC

This inert PoC shows code running under a lower IIS app-pool virtual account taking an elevated `dotnet-monitor` named-pipe client token, then using SCM to start an app-pool-placed `LocalSystem` service. The service writes a delayed SYSTEM-only marker after both monitor and worker exit. It is a controlled local elevation-of-privilege proof, **not** an anonymous or remote-only trigger.

## Clean reproduction

Use a **fresh disposable Windows Server 2025 x64** runner with an elevated Administrator `pwsh` 7 process, internet access to official Microsoft .NET downloads/NuGet, and .NET SDK **11.0.100**. The archive includes `run.ps1` and every lab program's C# source as PowerShell here-strings. The script enables the IIS URL Authorization feature if needed, installs the signed .NET 11.0.0 Hosting Bundle, and restores released `dotnet-trace 10.0.750501` and `dotnet-monitor 10.0.5`. It uses only localhost HTTP ports 8911, 52401 and 52402 and a temporary generated monitor API key. It changes local IIS and SCM state; run only on an owned disposable host, never production.

From a fresh extraction directory:

```powershell
Expand-Archive -LiteralPath .\MSRC_EOP03-L105_PoC.zip -DestinationPath .\EOP03-L105-clean
Set-Location .\EOP03-L105-clean
pwsh -NoProfile -ExecutionPolicy Bypass -File .\run.ps1
```

On the owned public Aeora repository, `runner/github-workflow.yml` is the **exact archive replay wrapper**. Its `actions/checkout@v4` retrieves this ZIP, `actions/setup-dotnet@v4` installs SDK 11.0.100, it prints the ZIP and extracted script hashes, extracts into a new runner-temp directory, then executes `pwsh -File .\run.ps1`. The original tested inline workflow is not needed for this run. The `RUNNER_TEMP` environment variable is optional for a manual owned Windows run; the script falls back to the system temp directory. It refuses an already existing `Pa30L105List` scratch directory or `Pa30L105ListProof` service rather than consuming stale state. A fresh runner is the primary repeat mechanism.

The script's success exit is gated on all of these observations:

1. The genuine .NET 11 IIS diagnostic pipe exists and a released `dotnet-trace` baseline succeeds. The lower app-pool worker directly fails protected ACL and SCM operations, copies the inert service fixture, then adds a second same-PID pipe instance.
2. The released elevated Administrator monitor is alive and unfiltered. Idle/no-request produces no fake contact; unauthenticated `GET /processes` returns 401/no contact.
3. A distinct local OS user with `ADMIN=False` is deliberately given the **one-run general API key** and sends six no-PID `GET /processes` requests. At least one HTTP 200 is required; the previous two exact runs saw six 200 responses each.
4. The lower pipe receives the monitor's first IPC byte, an Administrator SID at **Impersonation** level, and an Admin-only protected read/write. A direct SYSTEM-only write under Administrator stays denied. SCM creation/start of the app-pool-placed `Auto`/`LocalSystem` service succeeds.
5. The monitor stops, then the worker stops. The service remains Running with the same PID, logs `STARTED_SID=S-1-5-18`, and only later changes the SYSTEM-only marker. Final assertions and service stop/delete must pass.

The expected terminal line is `PA30_L105_NONADMIN_CALLER_ADMIN_MONITOR_SYSTEM_SERVICE_PASSED=True`. **Do not use that line alone as evidence**: the preceding identity, denial, service state and delayed-marker lines establish the terminal. The full two-run outputs and a single-right negative are in `evidence/` and indexed in `EVIDENCE.md`.

## Reset and limits

Repeat on a second fresh disposable Windows runner from the **same ZIP SHA-256**. On success, the workflow stops/deletes the service and removes the temporary low-user account. On a failure, discard the disposable runner; do not reuse a host whose IIS, scratch path or service state may be partial. No OS reboot is tested; `Auto` is an observed SCM setting, not proof of reboot survival.

Required conditions are lower IIS app-pool **code execution with enabled `SeImpersonatePrivilege`**, an elevated monitor, a new monitor connection after the second pipe binds, and an **authorized** process-list request. The app-pool attacker does not hold the monitor API key in this proof. A separate negative run disables only `SeImpersonatePrivilege`: the pipe/contact remain, but the token falls to Identification and no protected action occurs. The genuine endpoint's same-user trust model means this finding concerns the elevated **client's impersonation grant**, not ownership of the first runtime pipe.

The exact .NET bounty inclusion of these separately installed Microsoft diagnostics tools is unresolved from the public rules. The technical result supports an Important local EoP opinion; the non-default deployment/action prerequisites and private novelty remain for MSRC to evaluate. This archive is **not a submission** and contains no customer data or live credentials.
