# G09-L016: macOS .NET CN fallback across DNS NameConstraints

## Shortest complete reproduction

On an isolated, disposable **macOS 15 arm64** host with **.NET SDK 11.0.100 / Microsoft.NETCore.App and Microsoft.AspNetCore.App 11.0.0**, Python 3, OpenSSL, and passwordless `sudo` for the test host's System Keychain and `/etc/hosts`:

```sh
unzip MSRC_G09-L016_PoC.zip -d g09-l016
cd g09-l016
./run.sh
```

Run `./run.sh` a second time after the first exits. Each run builds the included stock ASP.NET Core project from source into a new temporary directory, sets temporary ordinary macOS root trust and a `forbidden.test` loopback route, executes the matrix, verifies the protected write, and restores trust and hosts in `finally`. The script fails nonzero if a control, cleanup assertion, or the protected write fails. The output is a sanitized JSON summary. Do not run this concurrently with another copy of the lab: it temporarily changes system trust and hosts.

While the bundled actor-issued certificate chain remains valid, the run uses that exact real-controller leaf and reports `"leaf_source": "actor_issued"`. After expiry, `run.sh` automatically generates a disposable equivalent constrained chain with macOS's `/usr/bin/openssl` and reports `"leaf_source": "locally_regenerated"`. Test this lasting consumer-only route now with `G09_FORCE_REGENERATE=1 ./run.sh`. Local signing does not prove namespace-only issuance; the retained issuer workflow and original signed output prove that separate actor-to-certificate join.

Expected output contains `"result": "pass"`, `"guard_statuses": {"no_cookie": 401, "no_owner_proof": 403, "wrong_cookie": 401, "valid": 200, "captured_replay": 200}`, `"writes_before_after_replay": [1, 2]`, `"attack_repeat_passed": true`, `"victim_proxy_configuration": false`, `"owned_root_removed": true`, and `"hosts_route_restored": true` (JSON formatting may differ). Before fixture expiry, `"leaf_source": "actor_issued"` and the actor leaf fingerprint is `eabcb604896b9703afaaf183f6b29b894cc6879cc5f7f1fd7875aa38e32dc7ba`; after local regeneration, the fingerprint changes. The denied explicit-SAN and wrong-host controls must capture no cookie. The real cookie value stays in a temporary mode-0600 file and is neither printed nor included in the bundle.

The test uses only disposable `.test` names, private lab keys, loopback traffic and inert state. No external network service, customer certificate or real credential is needed for the consumer run. The SDK may perform ordinary first-run setup or restore; the project has no external NuGet package reference. The bundled real-controller root and intermediate expire **30 November 2026**. The consumer replay automatically regenerates after that date. To repeat real namespace-only issuance with new certificates, see `issuer/README.md`.

## Claim and prerequisites

The actor starts as `system:serviceaccount:a31-tenant:actor` with `CertificateRequest` create/get permission in its namespace, no CA Secret access and no policy edit/use permission. In the paired cert-manager v1.21.1 test, default autoapproval **on** issued 24/24 actor-requested `CN=forbidden.test` no-SAN leaves under a separately held, critical `excluded;DNS:forbidden.test` intermediate; autoapproval **off** left both forbidden requests pending without certificates. The strict named approver policy was present but not bound to this actor. Thus the issuer setup effectively offers broad signing through default autoapproval; the issuer-policy condition is disclosed, not claimed as a new Microsoft flaw. The actor also needs separate on-path/name-routing influence and a victim macOS .NET client that trusts the private root and has an authenticated request to the protected origin. The actor does not need the CA key, origin key, victim cookie, or a custom victim TLS callback.

The Microsoft-owned decision under test is stock macOS .NET 11 TLS accepting a no-SAN leaf whose CN falls in the constrained issuer's excluded DNS subtree. The relevant released source builds the X.509 chain and then separately calls `MatchesHostname` with CN fallback, without binding the fallback CN to the issuer's DNS NameConstraints. The raw route forwards TLS bytes; it does not terminate the victim connection. A normal `SocketsHttpHandler` has `UseProxy=false` and no custom certificate validation. The victim automatically sends a real ASP.NET Core `Secure; HttpOnly; SameSite=Strict` cookie to the accepted actor leaf. A separate replay passes stock `.RequireAuthorization()` and changes a guarded write counter from 1 to 2. The actor's receipt alone does not perform that write.

This is a controlled private-PKI composition. It does not prove a named customer deployment, default public WebPKI issuance, a remote attacker changing a real victim's `/etc/hosts`, Critical code execution, or a new cert-manager vulnerability. Windows and tested released Linux TLS rejected this path. Public Erlang and OpenSSL/curl same-class prior art predates this test; Microsoft-specific novelty and bounty eligibility remain for MSRC to decide.

## Files

- `run.sh`, `regenerate-fixture.sh`, `a31_policy_transparent.py`, `a31_policy_transparent_Program.cs`: executable macOS consumer proof, including legitimate, denied, wrong-host, repeat, auth and cleanup assertions. The generator is a shelf-life fallback, not a substitute for issuer authorization evidence.
- `fixture/`: the exact actor-issued leaf and disposable lab signing material, plus admin-signed TLS controls. The forbidden-SAN control was **admin signed** after the actor request failed; it is not claimed as actor-obtained.
- `issuer/`: the exact owned GitHub Actions issuer workflow and instructions to repeat the real-controller autoapproval on/off matrix from fresh keys.
- `evidence/`: sanitized run result, independent certificate audit, and a separate strict-policy race variant that demonstrates a narrower policy-bound actor route but is timing dependent.
- `EVIDENCE.md`: claim-to-evidence and limitations table with source/run links.

## Validation and cleanup

`run.sh` checks the .NET version, fixture semantics, four authentication controls, two TLS rejection controls, attacker capture, authenticated write, repeat, and removal of the owned root/hosts entry. If interrupted between system mutations and Python's `finally`, inspect `security find-certificate -c 'A31 owned root' /Library/Keychains/System.keychain` and `/etc/hosts`; remove only this lab's root/marked route. Run solely on an owned disposable machine or runner.
