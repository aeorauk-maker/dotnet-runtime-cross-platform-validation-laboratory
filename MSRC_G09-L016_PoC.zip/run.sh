#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
command -v python3 >/dev/null
command -v dotnet >/dev/null
command -v openssl >/dev/null
command -v security >/dev/null
test "$(dotnet --version)" = '11.0.100'
sudo -n true
if [[ "${G09_FORCE_REGENERATE:-0}" == 1 ]] || \
   ! openssl x509 -in fixture/root.pem -checkend 86400 -noout >/dev/null 2>&1 || \
   ! openssl x509 -in fixture/issuer.pem -checkend 86400 -noout >/dev/null 2>&1 || \
   ! openssl x509 -in fixture/attack-issued.pem -checkend 86400 -noout >/dev/null 2>&1; then
  fresh_dir="$(mktemp -d "${TMPDIR:-/tmp}/g09-fixture.XXXXXX")"
  trap 'rm -rf "$fresh_dir"' EXIT
  ./regenerate-fixture.sh "$fresh_dir"
  export G09_FIXTURE_DIR="$fresh_dir"
  export G09_LEAF_SOURCE=locally_regenerated
fi
python3 ./a31_policy_transparent.py
