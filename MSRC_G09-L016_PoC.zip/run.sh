#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
command -v python3 >/dev/null
command -v dotnet >/dev/null
command -v openssl >/dev/null
command -v security >/dev/null
test "$(dotnet --version)" = '11.0.100'
sudo -n true
python3 ./a31_policy_transparent.py
