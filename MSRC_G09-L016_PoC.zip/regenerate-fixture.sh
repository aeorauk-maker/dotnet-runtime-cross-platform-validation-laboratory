#!/usr/bin/env bash
# Disposable signing fixture for a time-independent Microsoft TLS replay.
# It does not reproduce the namespace-only cert-manager issuance proof.
set -euo pipefail
out="${1:?output directory required}"
mkdir -p "$out"
cd "$out"

openssl ecparam -name prime256v1 -genkey -noout -out root.key
openssl req -x509 -new -sha256 -key root.key -subj '/CN=A31 owned root' \
  -days 365 -out root.pem \
  -addext 'basicConstraints=critical,CA:TRUE' \
  -addext 'keyUsage=critical,keyCertSign,cRLSign'
openssl ecparam -name prime256v1 -genkey -noout -out issuer.key
openssl req -new -sha256 -key issuer.key -subj '/CN=A31 constrained issuer' -out issuer.csr
cat > issuer.ext <<'EOF'
basicConstraints=critical,CA:TRUE,pathlen:0
keyUsage=critical,keyCertSign,cRLSign
nameConstraints=critical,excluded;DNS:forbidden.test
EOF
openssl x509 -req -sha256 -in issuer.csr -CA root.pem -CAkey root.key \
  -CAcreateserial -days 365 -out issuer.pem -extfile issuer.ext >/dev/null 2>&1
openssl ecparam -name prime256v1 -genkey -noout -out actor-leaf.key
make_leaf() {
  local name="$1" cn="$2" san="$3" ca="$4" cakey="$5" key="$6"
  local ext="$name.ext" csr="$name.csr"
  if [[ -n "$san" ]]; then
    openssl req -new -sha256 -key "$key" -subj "/CN=$cn" \
      -addext "subjectAltName=DNS:$san" -out "$csr"
  else
    openssl req -new -sha256 -key "$key" -subj "/CN=$cn" -out "$csr"
  fi
  {
    echo 'basicConstraints=critical,CA:FALSE'
    echo 'keyUsage=critical,digitalSignature'
    echo 'extendedKeyUsage=serverAuth'
    if [[ -n "$san" ]]; then echo "subjectAltName=DNS:$san"; fi
  } > "$ext"
  openssl x509 -req -sha256 -in "$csr" -CA "$ca" -CAkey "$cakey" \
    -CAcreateserial -days 365 -out "$name.pem" -extfile "$ext" >/dev/null 2>&1
}
make_leaf attack-issued forbidden.test '' issuer.pem issuer.key actor-leaf.key
make_leaf denied-issued forbidden.test forbidden.test issuer.pem issuer.key actor-leaf.key
make_leaf allowed-issued allowed.test allowed.test issuer.pem issuer.key actor-leaf.key
openssl ecparam -name prime256v1 -genkey -noout -out direct-root.key
make_leaf direct-root.cert forbidden.test forbidden.test root.pem root.key direct-root.key
echo 'A31_GENERATOR_VERIFY_ISSUER' >&2
openssl verify -CAfile root.pem issuer.pem >/dev/null
echo 'A31_GENERATOR_VERIFY_DIRECT' >&2
openssl verify -CAfile root.pem direct-root.cert.pem >/dev/null
[[ "$(openssl x509 -in attack-issued.pem -noout -text | grep -c 'X509v3 Subject Alternative Name' || true)" == 0 ]]
openssl x509 -in issuer.pem -noout -text | grep -q 'DNS:forbidden.test'
rm -f root.key issuer.key issuer.csr root.srl issuer.srl issuer.ext \
  ./*.csr ./*.ext
