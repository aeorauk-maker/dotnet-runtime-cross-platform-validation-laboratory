#!/usr/bin/env bash
# Disposable signing fixture for a time-independent Microsoft TLS replay.
# It does not reproduce the namespace-only cert-manager issuance proof.
set -euo pipefail
if [[ "$(uname -s)" == Darwin && -x /usr/bin/openssl ]]; then
  # Use the OS-supplied issuer for the macOS Security.framework replay.
  # The Actions image's PATH selects OpenSSL 1.1.1w, whose generated direct
  # control leaf is rejected by `security verify-cert` after root trust.
  openssl() { /usr/bin/openssl "$@"; }
fi
out="${1:?output directory required}"
mkdir -p "$out"
cd "$out"

openssl ecparam -name prime256v1 -genkey -noout -out root.key
root_label="A31 fresh root ${RANDOM}${RANDOM}"
printf '%s' "$root_label" > root-label.txt
openssl req -x509 -new -sha256 -key root.key -subj "/CN=$root_label" \
  -days 365 -out root.pem \
  -addext 'basicConstraints=critical,CA:TRUE' \
  -addext 'keyUsage=critical,keyCertSign,cRLSign'
openssl ecparam -name prime256v1 -genkey -noout -out issuer.key
openssl req -new -sha256 -key issuer.key -subj '/CN=A31 constrained issuer' -out issuer.csr
cat > issuer.ext <<'EOF'
basicConstraints=critical,CA:TRUE,pathlen:0
keyUsage=critical,keyCertSign,cRLSign
nameConstraints=critical,excluded;DNS:forbidden.test
EOF
openssl x509 -req -sha256 -in issuer.csr -CA root.pem -CAkey root.key \
  -CAcreateserial -days 365 -out issuer.pem -extfile issuer.ext >/dev/null 2>&1
openssl ecparam -name prime256v1 -genkey -noout -out actor-leaf.key
make_leaf() {
  local name="$1" cn="$2" san="$3" ca="$4" cakey="$5" key="$6"
  local ext="$name.ext" csr="$name.csr"
  if [[ -n "$san" ]]; then
    openssl req -new -sha256 -key "$key" -subj "/CN=$cn" \
      -addext "subjectAltName=DNS:$san" -out "$csr"
  else
    openssl req -new -sha256 -key "$key" -subj "/CN=$cn" -out "$csr"
  fi
  {
    echo 'basicConstraints=critical,CA:FALSE'
    echo 'keyUsage=critical,digitalSignature'
    echo 'extendedKeyUsage=serverAuth'
    if [[ -n "$san" ]]; then echo "subjectAltName=DNS:$san"; fi
  } > "$ext"
  openssl x509 -req -sha256 -in "$csr" -CA "$ca" -CAkey "$cakey" \
    -CAcreateserial -days 365 -out "$name.pem" -extfile "$ext" >/dev/null 2>&1
}
make_leaf attack-issued forbidden.test '' issuer.pem issuer.key actor-leaf.key
make_leaf denied-issued forbidden.test forbidden.test issuer.pem issuer.key actor-leaf.key
make_leaf allowed-issued allowed.test allowed.test issuer.pem issuer.key actor-leaf.key
openssl ecparam -name prime256v1 -genkey -noout -out direct-root.key
make_leaf direct-root.cert forbidden.test forbidden.test root.pem root.key direct-root.key
# The stock macOS trust check and .NET controls in a31_policy_transparent.py
# are the authoritative chain tests. OpenSSL 1.1.1 on the macOS runner can
# return error 20 for this generated intermediate at this preliminary step.
# Keep generator checks structural, then let the released consumer decide.
root_subject="$(openssl x509 -in root.pem -noout -subject | sed 's/^subject= *//')"
issuer_issuer="$(openssl x509 -in issuer.pem -noout -issuer | sed 's/^issuer= *//')"
direct_issuer="$(openssl x509 -in direct-root.cert.pem -noout -issuer | sed 's/^issuer= *//')"
[[ "$root_subject" == "$issuer_issuer" && "$root_subject" == "$direct_issuer" ]]
[[ "$(openssl x509 -in attack-issued.pem -noout -text | grep -c 'X509v3 Subject Alternative Name' || true)" == 0 ]]
openssl x509 -in issuer.pem -noout -text | grep -q 'DNS:forbidden.test'
rm -f root.key issuer.key issuer.csr root.srl issuer.srl issuer.ext \
  ./*.csr ./*.ext
