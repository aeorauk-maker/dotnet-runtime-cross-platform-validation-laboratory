#!/usr/bin/env bash
set -euo pipefail
here=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
mode=${1:-completed}
case "$mode" in completed|malformed) ;; *) echo 'usage: ./run.sh completed|malformed' >&2; exit 2;; esac
command -v docker >/dev/null
command -v python3 >/dev/null
command -v dotnet >/dev/null
test "$(dotnet --version)" = 11.0.100
tag="eop062-r14-poc-$(id -u)-$$"
cid=''
cleanup() {
    if [[ -n "$cid" ]]; then docker rm -f "$cid" >/dev/null 2>&1 || :; fi
    docker image rm "$tag" >/dev/null 2>&1 || :
    rm -f /tmp/eop062-r14-service-control.env
}
trap cleanup EXIT
docker build --quiet --tag "$tag" "$here/poc" >/dev/null
cid=$(docker run -d --user "$(id -u):$(id -g)" --cap-drop ALL --security-opt no-new-privileges --volume /tmp:/tmp "$tag")
export EOP062_SERVICE_ID="$cid"
export EOP062_MODE="$mode"
export GITHUB_WORKSPACE="$here"
python3 "$here/poc/eop062-gha-autostart-net11.py"
