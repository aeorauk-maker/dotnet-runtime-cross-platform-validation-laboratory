using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Runtime.InteropServices;
using System.Text.Json;

using var root = X509CertificateLoader.LoadCertificateFromFile("root.der");
using var intermediate = X509CertificateLoader.LoadCertificateFromFile("intermediate.der");
var results = new List<object>();
foreach (var file in new[] { "root-forbidden.der", "allowed.der", "forbidden.der", "cn-forbidden-san-allowed.der", "trailing-zero.der", "trailing-null.der" })
{
    try
    {
        using var leaf = X509CertificateLoader.LoadCertificateFromFile(file);
        using var chain = new X509Chain();
        chain.ChainPolicy.TrustMode = X509ChainTrustMode.CustomRootTrust;
        chain.ChainPolicy.CustomTrustStore.Add(root);
        chain.ChainPolicy.ExtraStore.Add(intermediate);
        chain.ChainPolicy.RevocationMode = X509RevocationMode.NoCheck;
        chain.ChainPolicy.VerificationFlags = X509VerificationFlags.NoFlag;
        chain.ChainPolicy.ApplicationPolicy.Add(new Oid("1.3.6.1.5.5.7.3.2"));
        var built = chain.Build(leaf);
        bool matchedAllowed = false, matchedForbidden = false;
        string? matchError = null;
        try
        {
            matchedAllowed = leaf.MatchesHostname("allowed.test");
            matchedForbidden = leaf.MatchesHostname("forbidden.test");
        }
        catch (Exception ex) { matchError = ex.GetType().Name + ":" + ex.HResult; }
        string? dnsName = null;
        string? dnsNameError = null;
        try { dnsName = leaf.GetNameInfo(X509NameType.DnsName, false); }
        catch (Exception ex) { dnsNameError = ex.GetType().Name + ":" + ex.HResult; }
        string? sanOnlyName = null;
        string? sanOnlyNameError = null;
        try { sanOnlyName = leaf.GetNameInfo(X509NameType.DnsFromAlternativeName, false); }
        catch (Exception ex) { sanOnlyNameError = ex.GetType().Name + ":" + ex.HResult; }
        results.Add(new
        {
            file,
            sha256 = Convert.ToHexString(SHA256.HashData(leaf.RawData)),
            sanCount = leaf.Extensions.Cast<X509Extension>().Count(x => x.Oid?.Value == "2.5.29.17"),
            sanRawHex = Convert.ToHexString(leaf.Extensions.Cast<X509Extension>().Single(x => x.Oid?.Value == "2.5.29.17").RawData),
            serialNumber = leaf.SerialNumber,
            built,
            statuses = chain.ChainStatus.Select(x => x.Status.ToString()).ToArray(),
            elements = chain.ChainElements.Cast<X509ChainElement>().Select(x => new { x.Certificate.Subject, statuses = x.ChainElementStatus.Select(s => s.Status.ToString()).ToArray() }).ToArray(),
            matchedAllowed,
            matchedForbidden,
            matchError,
            dnsName,
            dnsNameError,
            sanOnlyName,
            sanOnlyNameError
        });
    }
    catch (Exception ex) { results.Add(new { file, loadError = ex.GetType().Name + ":" + ex.HResult }); }
}
Console.WriteLine(JsonSerializer.Serialize(new
{
    runtime = RuntimeInformation.FrameworkDescription,
    os = RuntimeInformation.OSDescription,
    cryptoAssembly = typeof(X509Certificate2).Assembly.Location,
    cryptoSha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(typeof(X509Certificate2).Assembly.Location))),
    results
}, new JsonSerializerOptions { WriteIndented = true }));
